# chatbot.py

from transformers import pipeline
from langchain.schema import HumanMessage, AIMessage
from langchain_core.runnables import RunnableLambda
from langchain.memory import ConversationBufferMemory

# Load local model
sentiment_pipe = pipeline("text-classification", model="./results", tokenizer="./results")

def classify_sentiment(text):
    result = sentiment_pipe(text)[0]
    label_map = {
        "LABEL_0": "negative",
        "LABEL_1": "neutral",
        "LABEL_2": "positive"
    }
    sentiment = label_map.get(result["label"], "unknown")
    return sentiment, result["score"]

memory = ConversationBufferMemory(return_messages=True)

def respond_with_memory(human_message: HumanMessage):
    sentiment, confidence = classify_sentiment(human_message.content)

    if sentiment == "positive":
        bot_response = f"😊 I'm glad you're feeling good! (Confidence: {round(confidence*100, 2)}%)"
    elif sentiment == "neutral":
        bot_response = f"😐 Got it. Let me know if you need anything. (Confidence: {round(confidence*100, 2)}%)"
    elif sentiment == "negative":
        bot_response = f"😔 I'm here for you. What's bothering you? (Confidence: {round(confidence*100, 2)}%)"
    else:
        bot_response = "🤔 I'm not sure how you're feeling."

    memory.chat_memory.add_user_message(human_message.content)
    memory.chat_memory.add_ai_message(bot_response)

    return bot_response

# Exported function for Flask
def get_sentiment_response(user_input):
    return respond_with_memory(HumanMessage(content=user_input))
