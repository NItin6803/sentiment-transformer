import pandas as pd
import random

# Sample texts
positive_texts = [
    "I love this!", "Amazing experience.", "This is great.", "Fantastic product.", "Superb support."
]
negative_texts = [
    "I hate this!", "Terrible experience.", "Very bad service.", "Worst product ever.", "Not satisfied at all."
]
neutral_texts = [
    "It's okay.", "Not good, not bad.", "Just average.", "Neutral experience.", "Fine, I guess."
]

# Generate 300 of each class
data = []

for _ in range(300):
    data.append({"text": random.choice(positive_texts), "label": 2})  # POSITIVE
    data.append({"text": random.choice(neutral_texts), "label": 1})   # NEUTRAL
    data.append({"text": random.choice(negative_texts), "label": 0})  # NEGATIVE

# Shuffle and save
random.shuffle(data)
df = pd.DataFrame(data)
df.to_csv("dataset_neutral_900.csv", index=False)

print("✅ dataset_neutral_900.csv created with 900 samples.")
