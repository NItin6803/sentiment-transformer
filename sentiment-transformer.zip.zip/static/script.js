document.addEventListener("DOMContentLoaded", () => {
  const toggle = document.getElementById("toggle-mode");
  if (toggle) {
    toggle.addEventListener("click", () => {
      document.body.classList.toggle("dark");
      toggle.textContent = document.body.classList.contains("dark") ? "☀️" : "🌙";
    });
  }
});

function addMessage(sender, text) {
  const chatBox = document.getElementById("chat-box");
  const bubble = document.createElement("div");
  bubble.classList.add("chat-bubble", sender);
  bubble.textContent = text;
  chatBox.appendChild(bubble);
  chatBox.scrollTop = chatBox.scrollHeight;
}

function showTypingAnimation() {
  const chatBox = document.getElementById("chat-box");
  const typing = document.createElement("div");
  typing.id = "typing";
  typing.classList.add("chat-bubble", "bot");
  typing.textContent = "Typing...";
  chatBox.appendChild(typing);
  chatBox.scrollTop = chatBox.scrollHeight;
}

function removeTypingAnimation() {
  const typing = document.getElementById("typing");
  if (typing) typing.remove();
}

function sendMessage() {
  const inputBox = document.getElementById("user-input");
  const message = inputBox.value.trim();
  if (message === "") return;

  addMessage("user", message);
  inputBox.value = "";

  showTypingAnimation();

  fetch("/get_response", {
    method: "POST",
    body: JSON.stringify({ message }),
    headers: {
      "Content-Type": "application/json"
    }
  })
  .then(res => res.json())
  .then(data => {
    removeTypingAnimation();
    addMessage("bot", data.reply);
  });
}
