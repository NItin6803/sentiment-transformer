from flask import Flask, render_template, request, jsonify
from chatbot import get_sentiment_response  # This uses LangChain logic

app = Flask(__name__)

@app.route("/")
def home():
    return render_template("index.html")

@app.route("/get_response", methods=["POST"])
def get_response():
    try:
        data = request.get_json()
        user_msg = data.get("message")

        if not user_msg:
            return jsonify({"reply": "I didn't receive any message."})

        response = get_sentiment_response(user_msg)
        return jsonify({"reply": response})

    except Exception as e:
        print(f"Error: {e}")
        return jsonify({"reply": "Oops! Something went wrong."})

if __name__ == "__main__":
    app.run(debug=True)
